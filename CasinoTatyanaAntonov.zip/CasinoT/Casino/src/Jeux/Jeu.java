package Jeux;

import Casinos.*;
import Joueurs.*;

public abstract class Jeu {

    private String nom;
   

    public Jeu() {
        this.nom = "";
        
    }

    public Jeu(String nom) {
        this.nom = nom;
    }

    public Jeu(Jeu autre) {
        this.nom = autre.nom;
    }

    public boolean equals(Jeu autre) {
        if (this.nom.equals(autre.nom)) {
            return true;
        }
        return false;
    }

    public abstract int calculerGains(int mise);

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String toString() {
        String chaine;
        
        chaine = "Bienvenue dans le Jeu " + this.nom + " ! ";
        if (this.nom == "Roche Papier Ciseaux") {
            chaine += "\nRègle du jeu";
            chaine += "\n- Le jeux de \"pierre\" bat les ciseaux. \n"
                    + "- Le jeux de \"ciseaux\" bat la feuille . \n"
                    + "- La \"feuille\" bat la pierre. "
                    + "\nAinsi, chaque coup bat un autre coup. Si les joueurs révèlent le même symbole (pierre/pierre, feuille/feuille, ciseaux/ciseaux), cela fait match nul : personne ne marque de points.";
        } else {
            chaine += "\nLes règles du jeu Pile ou Face sont simples:"
                    + "\nPar défaut, le joueur prend face, donc si le casino affiche face, vous doublez votre mise.";
        }
        return chaine;
    }

}
