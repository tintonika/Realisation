
package Jeux;
import Joueurs.*;
import Casinos.*;

public class JeuPileOuFace extends Jeu  {

    public JeuPileOuFace() {
        super();
    }
    public JeuPileOuFace(String nom) {
        super(nom);
    }
    public JeuPileOuFace(JeuPileOuFace autre) {
        super(autre);
    }
    public int calculerGains(int mise) {
        //Assumons que pile vaut 0 et que le joueur prend toujours face.
        int pileOuFace = (int) (2 * Math.random());
        if (pileOuFace == 0) {
            mise+=mise;
            System.out.println("---Pile---Vous gagnez---Votre mise "+mise);
            return mise ;
        } else {
            System.out.println("---Face---Vous avez perdu---Votre mise "+mise);
            return 0;
        }

    }
    
}
