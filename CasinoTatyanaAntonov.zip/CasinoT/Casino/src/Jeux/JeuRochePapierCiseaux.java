package Jeux;

public class JeuRochePapierCiseaux extends Jeu {

    public JeuRochePapierCiseaux() {
        super();
    }

    public JeuRochePapierCiseaux(String nom) {
        super(nom);
    }

    public JeuRochePapierCiseaux(JeuRochePapierCiseaux autre) {
        super(autre);
    }

    public int calculerGains(int mise) {
        
        //Assumons que roche vaut 0, papier vaut 1, et ciseaux vaut 2. Le joueur prend toujours roche.
        int rochePapierCiseaux = (int) (3 * Math.random());
       
        System.out.println();
        if (rochePapierCiseaux == 0) {
            System.out.println("---Roche---Match nul---Votre mise "+mise);
            return mise ;
        } else if (rochePapierCiseaux == 1){
            System.out.println("---Papier---Vous avez perdu---Votre mise "+mise);
            return 0;
        }else {
            mise=mise*2;
            System.out.println("---Ciseaux---Vous avez gagné---Votre mise "+mise);
            return mise;
        }

    }

  
   

}
