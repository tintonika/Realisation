package Casinos;

import Jeux.*;
import Joueurs.*;

public class CasinoLegal extends Casino implements Comparable {

    int impot = 0;

    public CasinoLegal() {
        super();
    }

    public CasinoLegal(String nom, Jeu jeu1, Jeu jeu2) {
        super(nom, jeu1, jeu2);
    }

    public CasinoLegal(CasinoLegal autre) {
        super(autre);
    }

    public void collecterImpots() {

        for (int i = 0; i < this.getJoueursPresents(); i++) {

            impot = this.getJoueurs()[i].getCapital() / 100 * 15;

            this.getJoueurs()[i].setCapital(this.getJoueurs()[i].getCapital() - impot);

            System.out.println(this.getJoueurs()[i].getNom() + " impot" + impot + " et nouveau capital " + this.getJoueurs()[i].getCapital());
        }
    }
}
