package Casinos;

import Jeux.*;
import Joueurs.*;

public class CasinoIndien extends Casino  {

    public CasinoIndien() {
        super();
    }

    public CasinoIndien(String nom, Jeu jeu1, Jeu jeu2) {
        super(nom, jeu1, jeu2);
    }

    public CasinoIndien(CasinoIndien autre) {
        super(autre);
    }

    public void descenteDePolice() {

        for (int i = this.getJoueursPresents()-1; i!=-1; i--) {
            
          this.getJoueurs()[i].quitterCasino();
           
        
          

        }
     
        this.setJoueursPresents(0);
    }

}
