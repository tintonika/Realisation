package Casinos;

import Joueurs.*;
import Jeux.*;

public abstract class Casino implements Comparable {

    private String nom;
    private Joueur joueurs[];
    private int joueursPresents;
    private Jeu jeu1;
    private Jeu jeu2;

    public Casino() {
        this.nom = "";
        this.joueurs = null;
        this.joueursPresents = 0;
        this.jeu1 = null;
        this.jeu2 = null;

    }

    public Casino(String nom, Jeu jeu1, Jeu jeu2) {
        this.nom = nom;
        this.jeu1 = jeu1;
        this.jeu2 = jeu2;
        this.joueursPresents = 0;

        this.joueurs = new Joueur[10];

    }

    public Casino(Casino autre) {
        this.jeu1 = autre.jeu1;
        this.jeu2 = autre.jeu2;
        this.nom = autre.nom;
        this.joueursPresents = autre.joueursPresents;

        for (int i = 0; i < this.joueursPresents; i++) {
            this.joueurs[i] = autre.joueurs[i];
        }
    }

    public boolean equals(Casino autre) {
        if (this.nom.equals(autre.nom)
                && this.jeu1.equals(autre.jeu1) && this.jeu2.equals(autre.jeu2)) {
            return true;
        }
        return false;
    }

    public void setJoueurs(Joueur[] joueurs) {
        this.joueurs = joueurs;
    }

   
    public boolean checkPresent(Joueur joueur){
     
      
        for (int i = 0; i <this.joueursPresents; i++) {
           
            if (this.joueurs[i].equals(joueur)) {
                
                return false;
            } else {
                
            }
        }  return true; 
    }
    public void ajouterJoueur(Joueur joueur) {
        if(this.checkPresent(joueur)==true){
            if (((this.joueursPresents <= 10) && (joueur instanceof JoueurPauvre) && (joueur.getCapital() >= 10)) || ((this.joueursPresents <= 10) && (joueur instanceof JoueurRiche) && (joueur.getCapital() >= 1000))) {
                this.joueurs[this.joueursPresents] = joueur;
                 System.out.println(this.joueurs[this.joueursPresents].getNom()+" est ajouté au casino "+this.nom);
                this.joueursPresents++;
                joueur.joindreCasino(this);
            }

            if (this.joueursPresents > 10) {
                System.out.println("Désolé " + joueur.getNom() + ", le casino est plein!"+ joueur.getCasino().nom);
                
            }
            if ((joueur instanceof JoueurPauvre) && (joueur.getCapital() < 10) || ((joueur instanceof JoueurRiche) && (joueur.getCapital() < 1000))) {
                System.out.println("Désolé " + joueur.getNom() + ", n'a pas d'argent!");
                
            }
        }else{
        System.out.println("Le joueur " + joueur.getNom() + " déjà au casino "+this.nom+" !");
        }
    }
        
      
      
            
        
    
      
    

    public void enleverJoueur(Joueur joueur) {
       
        int co = this.joueursPresents;
        for (int i = 0; i < this.joueursPresents; i++) {
           
            if (this.joueurs[i].equals(joueur)) {
                System.out.println(this.joueurs[i].getNom() + " quittée le casino");
                this.joueurs[i] = null;
                this.joueursPresents--;
            }
        }
        for (int i = 0; i <co; i++) {
            if (this.joueurs[i] == null) {
                if (i == co - 1) {
                    this.joueurs[i] = null;

                } else {
                    this.joueurs[i] = this.joueurs[i + 1];
                    this.joueurs[i + 1] = null;

                }
            }
        }
        
    }

    public String toString() {
        String listeJoueur = "";
        for (int i = 0; i < joueursPresents; i++) {
            if (i == joueursPresents - 1) {
                listeJoueur += joueurs[i].getNom();
            } else {
                listeJoueur += joueurs[i].getNom() + ", ";
            }
        }

        String chaine;
        if (joueursPresents <= 1) {
            chaine = "Bienvenue au Casino " + this.nom + "!\nIl y a " + joueursPresents + " joueur présent.";
        } else {
            chaine = "Bienvenue au Casino " + this.nom + "!\nIl y a " + joueursPresents + " joueurs présents.";
        }
        if (joueursPresents > 0) {

            chaine += "\nVoici la liste: " + listeJoueur + ".";
        }
        return chaine;
    }

    public void jouer(Joueur joueur, int mise) {
        if (mise <= joueur.getCapital()) {
            joueur.setCapital(joueur.getCapital() - mise);
            int gains1 = this.getJeu1().calculerGains(mise);
            joueur.setCapital(joueur.getCapital() + gains1);
            if (mise <= joueur.getCapital()) {
                joueur.setCapital(joueur.getCapital()-mise);
                int gains2 = this.getJeu2().calculerGains(mise);
                joueur.setCapital(joueur.getCapital() + gains2);
            }
        } else {
            System.out.println("Vous n'avez pas asser d'argent...");
        }
    }

    public int getJoueursPresents() {
        return joueursPresents;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setJoueursPresents(int joueursPresents) {
        this.joueursPresents = joueursPresents;
    }

    public Jeu getJeu1() {
        return jeu1;
    }

    public Jeu getJeu2() {
        return jeu2;
    }

    public String getNom() {
        return nom;
    }

    public Joueur[] getJoueurs() {
        return joueurs;
    }

    public void afficherJoueurs() {

        for (int i = 0; i < this.getJoueursPresents(); i++) {
            System.out.println(this.getJoueurs()[i]);
        }
    }

    @Override
    public int compareTo(Object o) {

        int capitalCasino1 = 0;
        int capitalCasino2 = 0;
        Casino casino2 = (Casino) o;

        for (int i = 0; i < this.joueursPresents; i++) {

            capitalCasino1 += this.getJoueurs()[i].getCapital();

        }
        for (int i = 0; i < casino2.joueursPresents; i++) {
            capitalCasino2 += casino2.getJoueurs()[i].getCapital();

        }
        System.out.println("capitalCasino1= " + capitalCasino1 + " capitalCasino2= " + capitalCasino2);
        if (capitalCasino1 == capitalCasino2) {
            return 0;
        } else if (capitalCasino1 < capitalCasino2) {
            return -1;
        } else {
            return 1;
        }
    }

}
