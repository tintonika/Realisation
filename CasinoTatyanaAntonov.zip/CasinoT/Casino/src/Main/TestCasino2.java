package Main;

import Joueurs.*;
import Casinos.*;
import Jeux.*;

public class TestCasino2 {

    public static void main(String[] args) {
        int comparer = 0;

        JeuPileOuFace jeu1 = new JeuPileOuFace("Pile Ou Face");
        JeuRochePapierCiseaux jeu2 = new JeuRochePapierCiseaux("Roche Papier Ciseaux");

        CasinoLegal casLeg = new CasinoLegal("Montreal", jeu1, jeu2);
        CasinoIndien casInd = new CasinoIndien("Kahnawake", jeu1, jeu2);

        JoueurPauvre joueur1 = new JoueurPauvre("Steeve", 500, null);
        JoueurRiche joueur2 = new JoueurRiche("Emilie", 2000,null);
        JoueurRiche joueur3 = new JoueurRiche("Sylvain", 1000, null);
        JoueurRiche joueur4 = new JoueurRiche("Michael", 2000,null);
        JoueurPauvre joueur5 = new JoueurPauvre("Margo", 800,null);
        JoueurPauvre joueur6 = new JoueurPauvre("Bill", 100, null);
        JoueurRiche joueur7 = new JoueurRiche("Samir", 100,null);
        JoueurRiche joueur8 = new JoueurRiche("Sara", 2000, null);
        JoueurPauvre joueur9 = new JoueurPauvre("Margo", 800, null);
        JoueurPauvre joueur10 = new JoueurPauvre("Bill", 5,null);
        JoueurRiche joueur11 = new JoueurRiche("Stas", 1000, null);
        JoueurRiche joueur12 = new JoueurRiche("Sara", 2000, null);

        System.out.println("-----------------");
        System.out.println("1-Test ajout de joueurs");
        System.out.println("-----------------");
        
        casInd.ajouterJoueur(joueur1);
        casInd.ajouterJoueur(joueur2);
        casInd.ajouterJoueur(joueur3);
        casInd.ajouterJoueur(joueur4);
        casInd.ajouterJoueur(joueur5);
        casInd.ajouterJoueur(joueur6);
       casInd.ajouterJoueur(joueur5);
        
        
        System.out.println("-----------------");
        casInd.ajouterJoueur(joueur7);
        casLeg.ajouterJoueur(joueur8);
        casLeg.ajouterJoueur(joueur9);
       casLeg.ajouterJoueur(joueur10);
        casLeg.ajouterJoueur(joueur11);
        casLeg.ajouterJoueur(joueur12);
        
        System.out.println("-----------------");
        System.out.println("2-Afficher joueur de Casino Indien");
        System.out.println("-----------------");
        casInd.afficherJoueurs();
        System.out.println(casInd);
        System.out.println(joueur7);
        System.out.println("-----------------");

        System.out.println("-----------------");
        System.out.println("3-Afficher joueur de Casino Legal");
        System.out.println("-----------------");
        casLeg.afficherJoueurs();
        System.out.println("-----------------");

        System.out.println("-----------------");
        System.out.println("4-Test banqueRoute()");
        System.out.println("-----------------");
        joueur2.setCapEnt(20000);
        joueur2.setParadisFis(500);
        joueur2.banqueRoute();
        joueur3.banqueRoute();
        System.out.println("-----------------");

        System.out.println("-----------------");
        System.out.println("5-Afficher joueur de Casino Legal apre banqueRoute()");
        System.out.println("-----------------");
        System.out.println(casLeg);
        System.out.println("-----------------");

        System.out.println("-----------------");
        System.out.println("6-Test jouer au jeu");
        System.out.println("-----------------");
        System.out.println(joueur1);
        joueur1.joueur(50);
        casLeg.jouer(joueur9, 50);
        System.out.println(joueur1);
        System.out.println("-----------------");
        System.out.println(joueur7);
        joueur7.joueur(500);
        System.out.println("-----------------");

        System.out.println("-----------------");
        System.out.println("7-Test comparer casinos");
        System.out.println("-----------------");
        comparer = casInd.compareTo(casLeg);
        System.out.println("***** " + comparer);
        comparer = casLeg.compareTo(casInd);
        System.out.println("***** " + comparer);
        System.out.println("-----------------");
        
        System.out.println("-----------------");
        System.out.println("8-Test comparer joueurs");
        System.out.println("-----------------");
        comparer = joueur1.compareTo(joueur6);
        System.out.println("***** " + comparer);
        System.out.println("-----------------");

        System.out.println("-----------------");
        System.out.println("9-Test Impot");
        System.out.println("-----------------");
        casLeg.collecterImpots();
        System.out.println("-----------------");

        System.out.println("10-Test quitterCasino");
        System.out.println("-----------------");
        joueur3.quitterCasino();
        joueur7.quitterCasino();
        System.out.println(joueur3.toString());
        System.out.println(joueur7);
        System.out.println(casLeg);
        System.out.println("-----------------");
        
        System.out.println("-----------------");
        System.out.println("11-Test descenteDePolice()");
        System.out.println("-----------------");
        System.out.println(casInd);
        casInd.descenteDePolice();
        System.out.println(casInd);
        System.out.println();
        
        System.out.println("-----------------");
        
        System.out.println("-----------------");
        System.out.println("12-Test collecterCheque()");
        System.out.println("-----------------");
        joueur1.collecterCheque();
        System.out.println("-----------------");
        
        System.out.println("-----------------");
        System.out.println("13-Test toString() de jue");
        System.out.println("-----------------");
        System.out.println(jeu1);
        System.out.println("-----------------");
        System.out.println(jeu2);
    }

}
