package Joueurs;

import Casinos.*;

public abstract class Joueur implements Comparable {

    private String nom;
    private int capital;
    private Casino casino;

    public Joueur() {
        this.nom = "";
        this.capital = 0;
        this.casino = null;

    }

    public Joueur(String nom, int capital, Casino casino) {
        this.nom = nom;
        this.capital = capital;

        this.casino = casino;
    }

    //constructeur par copie
    public Joueur(Joueur autre) {
        this.nom = autre.nom;
        this.capital = autre.capital;

        this.casino = autre.casino;
    }

    //méthode equals 
    public boolean equals(Joueur autre) {
        if (this.nom.equals(autre.nom)
                && this.capital == (autre.capital)) {
            return true;
        }
        return false;
    }

    public String toString() {
        String chaine;
        chaine = "Le joueur " + this.nom + " - Capital : " + this.capital;
        return chaine;
    }

    public void joindreCasino(Casino casino) {

        this.casino = casino;

    }

    public void joueur(int mise) {
        if (casino != null && mise <= capital) {
            casino.jouer(this, mise);

        } else if (mise < capital) {
            System.out.println("Je n'ai pas assez d'argent pour miser");
        } else {
            System.out.println("Je ne peux pas jouer, je ne suis pas dans un casino");
        }
    }

    public void quitterCasino() {
        if (this.casino != null) {
            casino.enleverJoueur(this);
            casino = null;
        } else {
            System.out.println(this.nom + " n'est pas dans un casino!");
        }

    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public int getCapital() {
        return capital;
    }

    public void setCapital(int capital) {
        this.capital = capital;
    }

    public Casino getCasino() {
        return casino;
    }

    public void setCasino(Casino casino) {
        this.casino = casino;
    }

    @Override
    public int compareTo(Object o) {
        int capitalJoueur1 = this.getCapital();

        Joueur joueur2 = (Joueur) o;
        int capitalJoueur2 = joueur2.getCapital();

        System.out.println("capitalJoueur1= " + capitalJoueur1 + "capitalJoueur2= " + capitalJoueur2);
        if (capitalJoueur1 == capitalJoueur2) {
            return 0;
        } else if (capitalJoueur1 < capitalJoueur2) {
            return -1;
        } else {
            return 1;
        }
    }

}
