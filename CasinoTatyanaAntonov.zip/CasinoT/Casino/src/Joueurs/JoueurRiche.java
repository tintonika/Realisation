package Joueurs;

import Casinos.*;
import Jeux.*;

public class JoueurRiche extends Joueur implements Comparable {

    private int capEnt;
    private int paradisFis;

    public JoueurRiche() {
        super();
        this.capEnt = 0;
        this.paradisFis = 0;
    }

    public JoueurRiche(String nom, int capital, Casino casino) {
        super(nom, capital, casino);
        this.capEnt = 0;
        this.paradisFis = 0;
    }

    public JoueurRiche(JoueurRiche autre) {
        super(autre);
        this.capEnt = autre.capEnt;
        this.paradisFis = autre.paradisFis;
    }

    public void banqueRoute() {
        if (this.capEnt != 0 && this.paradisFis != 0) {
            this.capEnt = 0;
            this.paradisFis = 0;
            this.setCapital(0);
            this.quitterCasino();

            System.out.println("Et son capital est " + this.getCapital() + " !");
        } else {
            return;
        }

    }

    public int getCapEnt() {
        return capEnt;
    }

    public int getParadisFis() {
        return paradisFis;
    }

    public void setCapEnt(int capEnt) {
        this.capEnt = capEnt;
    }

    public void setParadisFis(int paradisFis) {
        this.paradisFis = paradisFis;
    }

}
