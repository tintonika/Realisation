package Joueurs;

import Casinos.*;
import Jeux.*;

import java.util.Calendar;

public class JoueurPauvre extends Joueur implements Comparable{

    Calendar today = Calendar.getInstance();

    public JoueurPauvre() {
        super();
    }

    public JoueurPauvre(String nom, int capital, Casino casino) {
        super(nom, capital, casino);
      
    }

    public JoueurPauvre(JoueurRiche autre) {
        super(autre);
    }

    public void collecterCheque() {

        Calendar calendar = Calendar.getInstance();
        int today = calendar.get(Calendar.DAY_OF_MONTH);
        //System.out.println("Ajourd'hui " + today);
        if (today == 1) {
            this.setCapital(this.getCapital() + 700);
            System.out.println("Ajourd'hui le premier du mois, vous collectez un chéque de 700$! Votre capital est : " + this.getCapital());
        } else {
            System.out.println("Le premier du mois, vous pouvez collecter un chéque de 700$!");
        }

    }

}
